#!/usr/bin/env python3
"""
Audio Transcription Server
Flask + SocketIO server for managing and transcribing audio recordings
"""
import os
import sys
import argparse
import logging
import threading
import queue
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

from flask import Flask, send_from_directory
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import speech_recognition as sr
from pydub import AudioSegment

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Flask app setup
app = Flask(__name__, static_folder='static', static_url_path='')
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Global state
RECORDINGS_DIR = Path('recordings')
transcription_queue = queue.Queue()
file_registry: Dict[str, dict] = {}
shutdown_event = threading.Event()


class AudioFileHandler(FileSystemEventHandler):
    """Watches for new .mp3 files and queues them for transcription"""
    
    def on_created(self, event):
        if event.is_directory:
            return
        
        if event.src_path.endswith('.mp3'):
            logger.info(f"New audio file detected: {event.src_path}")
            file_path = Path(event.src_path)
            self._queue_for_transcription(file_path)
    
    def _queue_for_transcription(self, file_path: Path):
        """Add file to transcription queue"""
        transcription_queue.put(file_path)
        
        # Add to registry immediately
        filename = file_path.name
        if filename not in file_registry:
            file_registry[filename] = {
                'filename': filename,
                'transcription': None,
                'status': 'queued',
                'added': datetime.now().isoformat()
            }
            # Notify clients of new file
            socketio.emit('file_update', file_registry[filename], broadcast=True)


def scan_existing_files():
    """Scan recordings directory for existing files"""
    logger.info(f"Scanning {RECORDINGS_DIR} for existing files...")
    
    if not RECORDINGS_DIR.exists():
        logger.warning(f"Recordings directory {RECORDINGS_DIR} does not exist. Creating it...")
        RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
        return
    
    mp3_files = list(RECORDINGS_DIR.glob('*.mp3'))
    logger.info(f"Found {len(mp3_files)} MP3 files")
    
    for mp3_file in mp3_files:
        filename = mp3_file.name
        txt_file = mp3_file.with_suffix('.txt')
        
        # Read existing transcription if available
        transcription = None
        status = 'pending'
        if txt_file.exists():
            try:
                transcription = txt_file.read_text(encoding='utf-8')
                status = 'completed'
            except Exception as e:
                logger.error(f"Error reading transcription for {filename}: {e}")
        
        file_registry[filename] = {
            'filename': filename,
            'transcription': transcription,
            'status': status,
            'added': datetime.fromtimestamp(mp3_file.stat().st_mtime).isoformat()
        }
        
        # Queue files without transcription
        if transcription is None:
            transcription_queue.put(mp3_file)


def transcribe_audio(file_path: Path) -> Optional[str]:
    """
    Transcribe an audio file using speech recognition
    Converts MP3 to WAV first, then uses Google Speech Recognition
    """
    try:
        logger.info(f"Starting transcription of {file_path.name}")
        
        # Convert MP3 to WAV
        wav_path = file_path.with_suffix('.wav')
        audio = AudioSegment.from_mp3(str(file_path))
        audio.export(str(wav_path), format='wav')
        
        # Initialize recognizer
        recognizer = sr.Recognizer()
        
        # Load audio file
        with sr.AudioFile(str(wav_path)) as source:
            audio_data = recognizer.record(source)
        
        # Perform transcription
        text = recognizer.recognize_google(audio_data)
        
        # Clean up temporary WAV file
        wav_path.unlink()
        
        logger.info(f"Successfully transcribed {file_path.name}")
        return text
        
    except sr.UnknownValueError:
        logger.warning(f"Could not understand audio in {file_path.name}")
        return "[Audio not intelligible]"
    except sr.RequestError as e:
        logger.error(f"Could not request results from speech recognition service: {e}")
        return "[Transcription service error]"
    except Exception as e:
        logger.error(f"Error transcribing {file_path.name}: {e}")
        return f"[Transcription error: {str(e)}]"


def transcription_worker():
    """Background worker that processes transcription queue"""
    logger.info("Transcription worker started")
    
    while not shutdown_event.is_set():
        try:
            # Get file from queue with timeout
            file_path = transcription_queue.get(timeout=1)
            
            filename = file_path.name
            
            # Update status to processing
            if filename in file_registry:
                file_registry[filename]['status'] = 'processing'
                socketio.emit('file_update', file_registry[filename], broadcast=True)
            
            # Perform transcription
            transcription = transcribe_audio(file_path)
            
            # Save transcription to file
            txt_path = file_path.with_suffix('.txt')
            txt_path.write_text(transcription, encoding='utf-8')
            
            # Update registry
            if filename in file_registry:
                file_registry[filename]['transcription'] = transcription
                file_registry[filename]['status'] = 'completed'
                
                # Broadcast update to all clients
                socketio.emit('file_update', file_registry[filename], broadcast=True)
                logger.info(f"Transcription complete and broadcasted for {filename}")
            
            transcription_queue.task_done()
            
        except queue.Empty:
            continue
        except Exception as e:
            logger.error(f"Error in transcription worker: {e}")
    
    logger.info("Transcription worker stopped")


# SocketIO event handlers
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    import flask
    logger.info(f"Client connected: {flask.request.sid}")
    emit('connected', {'message': 'Connected to transcription server'})


@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    import flask
    logger.info(f"Client disconnected: {flask.request.sid}")


@socketio.on('get_files')
def handle_get_files(data=None):
    """Send list of all files to requesting client"""
    import flask
    logger.info(f"Client {flask.request.sid} requested file list")
    
    # Convert registry to list sorted by filename
    files = sorted(file_registry.values(), key=lambda x: x['filename'])
    
    emit('files_list', {
        'files': files,
        'total': len(files)
    })


@socketio.on('request_audio_stream')
def handle_audio_stream_request(data):
    """Handle request to stream audio file"""
    import flask
    filename = data.get('filename')
    
    if not filename:
        emit('error', {'message': 'No filename provided'})
        return
    
    if filename not in file_registry:
        emit('error', {'message': f'File not found: {filename}'})
        return
    
    logger.info(f"Client {flask.request.sid} requesting audio stream for {filename}")
    
    # Send audio URL (will be served via Flask static route)
    emit('audio_stream_ready', {
        'filename': filename,
        'url': f'/audio/{filename}'
    })


# Flask routes
@app.route('/')
def index():
    """Serve the main application"""
    return send_from_directory('static', 'index.html')


@app.route('/audio/<path:filename>')
def serve_audio(filename):
    """Serve audio files"""
    return send_from_directory(RECORDINGS_DIR, filename)


def start_file_watcher():
    """Start the file system watcher"""
    event_handler = AudioFileHandler()
    observer = Observer()
    observer.schedule(event_handler, str(RECORDINGS_DIR), recursive=False)
    observer.start()
    logger.info(f"File watcher started on {RECORDINGS_DIR}")
    return observer


def main():
    """Main entry point"""
    global RECORDINGS_DIR
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Audio Transcription Server')
    parser.add_argument(
        '--recordings-dir',
        type=str,
        default='recordings',
        help='Directory containing audio recordings (default: recordings)'
    )
    parser.add_argument(
        '--host',
        type=str,
        default='127.0.0.1',
        help='Host to bind to (default: 127.0.0.1)'
    )
    parser.add_argument(
        '--port',
        type=int,
        default=5000,
        help='Port to bind to (default: 5000)'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug mode'
    )
    
    args = parser.parse_args()
    
    # Set recordings directory
    RECORDINGS_DIR = Path(args.recordings_dir)
    logger.info(f"Using recordings directory: {RECORDINGS_DIR}")
    
    # Scan existing files
    scan_existing_files()
    
    # Start transcription worker thread
    worker_thread = threading.Thread(target=transcription_worker, daemon=True)
    worker_thread.start()
    
    # Start file watcher
    observer = start_file_watcher()
    
    try:
        # Start server
        logger.info(f"Starting server on {args.host}:{args.port}")
        socketio.run(
            app,
            host=args.host,
            port=args.port,
            debug=args.debug,
            allow_unsafe_werkzeug=True
        )
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    finally:
        shutdown_event.set()
        observer.stop()
        observer.join()
        worker_thread.join(timeout=5)
        logger.info("Shutdown complete")


if __name__ == '__main__':
    main()
